package com.example.npcmod.network;

import com.example.npcmod.NpcMod;
import com.example.npcmod.reputation.ReputationManager;
import com.example.npcmod.screen.TransporterScreenHandler;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class ModPackets {
    public static final Identifier DIALOGUE_CHOICE = NpcMod.id("dialogue_choice");
    public static final Identifier TELEPORT_REQUEST = NpcMod.id("teleport_request");

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(DIALOGUE_CHOICE, (server, player, handler, buf, responseSender) -> {
            int delta = buf.readInt();
            server.execute(() -> {
                ReputationManager.changeReputation(server, player.getUuid(), delta);
                player.sendMessage(Text.literal("§aРепутация изменена на " + delta), true);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(TELEPORT_REQUEST, (server, player, handler1, buf, responseSender) -> {
            server.execute(() -> {
                ScreenHandler screenHandler = player.currentScreenHandler;
                if (screenHandler instanceof TransporterScreenHandler transporter) {
                    transporter.teleport(player);
                }
            });
        });
    }

    public static void registerClient() {}
}
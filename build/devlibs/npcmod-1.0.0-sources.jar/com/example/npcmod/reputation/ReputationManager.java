package com.example.npcmod.reputation;

import com.example.npcmod.NpcMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.WorldSavePath;

import java.io.*;
import java.lang.reflect.Type;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ReputationManager {
    private static final Map<UUID, Integer> REPUTATIONS = new HashMap<>();
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Type TYPE = new TypeToken<Map<UUID, Integer>>(){}.getType();

    public static int getReputation(UUID playerId) {
        return REPUTATIONS.getOrDefault(playerId, 0);
    }

    public static int changeReputation(MinecraftServer server, UUID playerId, int delta) {
        int current = getReputation(playerId);
        int newValue = Math.max(-100, Math.min(100, current + delta));
        REPUTATIONS.put(playerId, newValue);
        save(server);
        return newValue;
    }

    public static void load(MinecraftServer server) {
        REPUTATIONS.clear();
        Path path = getSavePath(server);
        if (path.toFile().exists()) {
            try (Reader reader = new FileReader(path.toFile())) {
                Map<UUID, Integer> loaded = GSON.fromJson(reader, TYPE);
                if (loaded != null) REPUTATIONS.putAll(loaded);
            } catch (IOException e) {}
        }
    }

    public static void save(MinecraftServer server) {
        Path path = getSavePath(server);
        path.getParent().toFile().mkdirs();
        try (Writer writer = new FileWriter(path.toFile())) {
            GSON.toJson(REPUTATIONS, writer);
        } catch (IOException e) {}
    }

    private static Path getSavePath(MinecraftServer server) {
        return server.getSavePath(WorldSavePath.ROOT).resolve("npcmod").resolve("reputations.json");
    }
}
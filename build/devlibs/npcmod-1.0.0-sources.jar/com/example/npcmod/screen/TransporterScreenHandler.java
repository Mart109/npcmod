package com.example.npcmod.screen;

import com.example.npcmod.entity.CustomNpcEntity;
import com.example.npcmod.money.MoneyManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;

public class TransporterScreenHandler extends ScreenHandler {
    private final ScreenHandlerContext context;
    private final CustomNpcEntity npc;

    public TransporterScreenHandler(int syncId, PlayerInventory playerInventory) {
        this(syncId, playerInventory, ScreenHandlerContext.EMPTY, null);
    }

    public TransporterScreenHandler(int syncId, PlayerInventory playerInventory, ScreenHandlerContext context, CustomNpcEntity npc) {
        super(ModScreenHandlers.TRANSPORTER_SCREEN_HANDLER, syncId);
        this.context = context;
        this.npc = npc;
    }

    public boolean teleport(ServerPlayerEntity player) {
        var info = npc.getNpcInfo();
        if (info == null) return false;

        int price = info.teleportPrice;
        if (!MoneyManager.spendMoney(player.getUuid(), price)) {
            player.sendMessage(Text.literal("§cНедостаточно монет! Нужно " + price), true);
            return false;
        }

        BlockPos dest = switch (info.destinationName) {
            case "§6🏛️ Золотой Город" -> new BlockPos(1000, 64, 1000);
            case "§a🌳 Изумрудный Лес" -> new BlockPos(-500, 70, 800);
            default -> new BlockPos(0, 64, 0);
        };

        player.teleport((ServerWorld) player.getWorld(), dest.getX()+0.5, dest.getY(), dest.getZ()+0.5, player.getYaw(), player.getPitch());
        player.sendMessage(Text.literal("§a✨ Телепортация в " + info.destinationName + "!"), true);
        return true;
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return true;
    }
}
package com.example.npcmod.screen;

import com.example.npcmod.entity.CustomNpcEntity;
import com.example.npcmod.money.MoneyManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.inventory.SimpleInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.ScreenHandlerContext;
import net.minecraft.screen.slot.Slot;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class MerchantScreenHandler extends ScreenHandler {
    private final ScreenHandlerContext context;
    private final CustomNpcEntity npc;
    private final Inventory inventory;

    private static final ItemStack[] OFFERS = {
            new ItemStack(Items.IRON_INGOT, 1),
            new ItemStack(Items.DIAMOND, 1),
            new ItemStack(Items.EMERALD, 1),
            new ItemStack(Items.GOLDEN_APPLE, 1)
    };
    private static final int[] PRICES = {5, 20, 15, 30};

    public MerchantScreenHandler(int syncId, PlayerInventory playerInventory) {
        this(syncId, playerInventory, ScreenHandlerContext.EMPTY, null);
    }

    public MerchantScreenHandler(int syncId, PlayerInventory playerInventory, ScreenHandlerContext context, CustomNpcEntity npc) {
        super(ModScreenHandlers.MERCHANT_SCREEN_HANDLER, syncId);
        this.context = context;
        this.npc = npc;
        this.inventory = new SimpleInventory(4);

        for (int i = 0; i < 4; i++) {
            this.addSlot(new Slot(inventory, i, 30 + i * 30, 35) {
                @Override
                public boolean canInsert(ItemStack stack) { return false; }
            });
            inventory.setStack(i, OFFERS[i].copy());
        }

        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.addSlot(new Slot(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (int i = 0; i < 9; ++i) {
            this.addSlot(new Slot(playerInventory, i, 8 + i * 18, 142));
        }
    }

    @Override
    public boolean onButtonClick(PlayerEntity player, int id) {
        if (id >= 0 && id < OFFERS.length && player instanceof ServerPlayerEntity serverPlayer) {
            int price = PRICES[id];
            if (MoneyManager.spendMoney(serverPlayer.getUuid(), price)) {
                ItemStack bought = OFFERS[id].copy();
                if (!serverPlayer.getInventory().insertStack(bought)) {
                    serverPlayer.dropItem(bought, false);
                }
                serverPlayer.sendMessage(Text.literal("§aКуплено за " + price + " монет!"), true);
            } else {
                serverPlayer.sendMessage(Text.literal("§cНедостаточно монет! Нужно " + price), true);
            }
        }
        return true;
    }

    @Override
    public ItemStack quickMove(PlayerEntity player, int slot) {
        return ItemStack.EMPTY;
    }

    @Override
    public boolean canUse(PlayerEntity player) {
        return true;
    }
}
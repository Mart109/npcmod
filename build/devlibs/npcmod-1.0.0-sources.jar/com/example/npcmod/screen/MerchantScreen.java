package com.example.npcmod.screen;

import com.example.npcmod.NpcMod;
import com.example.npcmod.money.MoneyManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class MerchantScreen extends HandledScreen<MerchantScreenHandler> {
    private static final Identifier TEXTURE = new Identifier(NpcMod.MOD_ID, "textures/gui/merchant_bg.png");

    public MerchantScreen(MerchantScreenHandler handler, PlayerInventory inventory, Text title) {
        super(handler, inventory, title);
        this.backgroundWidth = 176;
        this.backgroundHeight = 166;
    }

    @Override
    protected void init() {
        super.init();
        int x = (width - backgroundWidth) / 2;
        int y = (height - backgroundHeight) / 2;

        addDrawableChild(ButtonWidget.builder(Text.literal("§7Железо §6(5)"), btn -> handler.onButtonClick(client.player, 0))
                .dimensions(x + 30, y + 30, 60, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("§bАлмаз §6(20)"), btn -> handler.onButtonClick(client.player, 1))
                .dimensions(x + 100, y + 30, 60, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("§aИзумруд §6(15)"), btn -> handler.onButtonClick(client.player, 2))
                .dimensions(x + 30, y + 55, 60, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("§6Зол.яблоко §6(30)"), btn -> handler.onButtonClick(client.player, 3))
                .dimensions(x + 100, y + 55, 60, 20).build());
    }

    @Override
    protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
        RenderSystem.setShaderColor(1,1,1,1);
        int x = (width - backgroundWidth) / 2;
        int y = (height - backgroundHeight) / 2;
        context.drawTexture(TEXTURE, x, y, 0, 0, backgroundWidth, backgroundHeight);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        super.render(context, mouseX, mouseY, delta);
        int x = (width - backgroundWidth) / 2;
        int y = (height - backgroundHeight) / 2;

        var player = MinecraftClient.getInstance().player;
        if (player != null) {
            int money = MoneyManager.getMoney(player.getUuid());
            context.drawText(textRenderer, Text.literal("§6💰 " + money), x + 8, y + 6, 0xFFFFFF, false);
        }
        drawMouseoverTooltip(context, mouseX, mouseY);
    }
}
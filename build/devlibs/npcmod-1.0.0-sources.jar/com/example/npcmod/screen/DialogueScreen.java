package com.example.npcmod.screen;

import com.example.npcmod.NpcMod;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public class DialogueScreen extends HandledScreen<DialogueScreenHandler> {
    private static final Identifier TEXTURE = new Identifier(NpcMod.MOD_ID, "textures/gui/dialogue_bg.png");

    public DialogueScreen(DialogueScreenHandler handler, PlayerInventory inventory, Text title) {
        super(handler, inventory, title);
        this.backgroundWidth = 350;
        this.backgroundHeight = 220;
        this.playerInventoryTitleY = 1000;
    }

    @Override
    protected void init() {
        super.init();
        int x = (width - backgroundWidth) / 2;
        int y = (height - backgroundHeight) / 2;

        addDrawableChild(ButtonWidget.builder(
                        Text.literal("§a✨ Помочь (+10)"),
                        btn -> sendChoice(10))
                .dimensions(x + 50, y + 140, 120, 20).build());

        addDrawableChild(ButtonWidget.builder(
                        Text.literal("§c💔 Отказать (-5)"),
                        btn -> sendChoice(-5))
                .dimensions(x + 180, y + 140, 120, 20).build());

        addDrawableChild(ButtonWidget.builder(
                        Text.literal("§7🚪 Уйти"),
                        btn -> close())
                .dimensions(x + 270, y + 10, 60, 20).build());
    }

    private void sendChoice(int delta) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(delta);
        ClientPlayNetworking.send(NpcMod.id("dialogue_choice"), buf);
        close();
    }

    @Override
    protected void drawBackground(DrawContext context, float delta, int mouseX, int mouseY) {
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        int x = (width - backgroundWidth) / 2;
        int y = (height - backgroundHeight) / 2;
        context.drawTexture(TEXTURE, x, y, 0, 0, backgroundWidth, backgroundHeight);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        super.render(context, mouseX, mouseY, delta);
        int x = (width - backgroundWidth) / 2;
        int y = (height - backgroundHeight) / 2;

        context.drawText(textRenderer, Text.literal("§6§lПривет, путник!"), x + 20, y + 20, 0xFFFFFF, false);
        context.drawText(textRenderer, Text.literal("§7Твои поступки определяют твою судьбу."), x + 20, y + 45, 0xCCCCCC, false);
        context.drawText(textRenderer, Text.literal("§eВыбери мудро:"), x + 20, y + 75, 0xFFAA00, false);
    }
}
package com.example.npcmod;

import com.example.npcmod.entity.ModEntities;
import com.example.npcmod.entity.client.CustomNpcRenderer;
import com.example.npcmod.network.ModPackets;
import com.example.npcmod.screen.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.class_3929;

public class NpcModClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.CUSTOM_NPC, CustomNpcRenderer::new);

        class_3929.method_17542(ModScreenHandlers.DIALOGUE_SCREEN_HANDLER, DialogueScreen::new);
        class_3929.method_17542(ModScreenHandlers.MERCHANT_SCREEN_HANDLER, MerchantScreen::new);
        class_3929.method_17542(ModScreenHandlers.TRANSPORTER_SCREEN_HANDLER, TransporterScreen::new);

        ModPackets.registerClient();
    }
}
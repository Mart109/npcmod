package com.example.npcmod.entity.client;

import com.example.npcmod.entity.CustomNpcEntity;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5617;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class CustomNpcRenderer extends GeoEntityRenderer<CustomNpcEntity> {
    public CustomNpcRenderer(class_5617.class_5618 renderManager) {
        super(renderManager, new CustomNpcModel());
        this.field_4673 = 0.5f;
    }

    @Override
    public void render(CustomNpcEntity entity, float entityYaw, float partialTick,
                       class_4587 poseStack, class_4597 bufferSource,
                       int packedLight) {
        poseStack.method_22905(1.0f, 1.0f, 1.0f);
        super.method_3936(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
    }
}
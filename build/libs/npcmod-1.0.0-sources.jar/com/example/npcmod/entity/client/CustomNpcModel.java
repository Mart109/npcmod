package com.example.npcmod.entity.client;

import com.example.npcmod.NpcMod;
import com.example.npcmod.entity.CustomNpcEntity;
import com.example.npcmod.npcdata.NpcData.Info;
import net.minecraft.class_2960;
import software.bernie.geckolib.model.GeoModel;

public class CustomNpcModel extends GeoModel<CustomNpcEntity> {
    @Override
    public class_2960 getModelResource(CustomNpcEntity animatable) {
        return new class_2960(NpcMod.MOD_ID, "geo/custom_npc.geo.json");
    }

    @Override
    public class_2960 getTextureResource(CustomNpcEntity animatable) {
        var info = animatable.getNpcInfo();
        return info != null ? info.texture : new class_2960(NpcMod.MOD_ID, "textures/entity/merchant1.png");
    }

    @Override
    public class_2960 getAnimationResource(CustomNpcEntity animatable) {
        return new class_2960(NpcMod.MOD_ID, "animations/custom_npc.animation.json");
    }
}
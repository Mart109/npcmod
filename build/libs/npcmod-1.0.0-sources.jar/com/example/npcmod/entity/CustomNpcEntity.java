package com.example.npcmod.entity;

import com.example.npcmod.npcdata.NpcData;
import com.example.npcmod.screen.*;
import net.minecraft.class_11;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1314;
import net.minecraft.class_1347;
import net.minecraft.class_1361;
import net.minecraft.class_1376;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3914;
import net.minecraft.class_5132;
import net.minecraft.class_5134;
import net.minecraft.entity.ai.goal.*;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.GeoAnimatable;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.core.object.PlayState;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.ArrayList;
import java.util.List;

public class CustomNpcEntity extends class_1314 implements GeoEntity, class_3908 {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private NpcData.Info npcInfo;
    private int npcIndex = -1;
    private final List<class_2338> waypoints = new ArrayList<>();
    private int currentWaypoint = 0;
    private int ticksStuck = 0;

    public CustomNpcEntity(class_1299<? extends class_1314> entityType, class_1937 world) {
        super(entityType, world);
    }

    public static class_5132.class_5133 method_26828() {
        return class_1308.method_26828()
                .method_26868(class_5134.field_23716, 40.0)
                .method_26868(class_5134.field_23719, 0.25)
                .method_26868(class_5134.field_23717, 35.0);
    }

    @Override
    protected void method_5959() {
        this.field_6201.method_6277(0, new class_1347(this));
        this.field_6201.method_6277(1, new class_1361(this, class_1657.class, 8.0f));
        this.field_6201.method_6277(2, new class_1376(this));
    }

    public void setNpcInfo(int index) {
        this.npcIndex = index;
        if (index >= 0 && index < 33) {
            NpcData.registerNpc(this.method_5667(), index);
            this.npcInfo = NpcData.getInfo(this.method_5667());
            this.method_5665(class_2561.method_43470(npcInfo.name + " " + npcInfo.type.displayName));
            this.method_5880(true);
            setupWaypoints();
        }
    }

    private void setupWaypoints() {
        class_2338 home = this.method_24515();
        waypoints.clear();
        waypoints.add(home);
        waypoints.add(home.method_10069(5, 0, 0));
        waypoints.add(home.method_10069(5, 0, 5));
        waypoints.add(home.method_10069(0, 0, 5));
        waypoints.add(home.method_10069(-5, 0, 5));
        waypoints.add(home.method_10069(-5, 0, 0));
        waypoints.add(home.method_10069(-5, 0, -5));
        waypoints.add(home.method_10069(0, 0, -5));
        waypoints.add(home.method_10069(5, 0, -5));
    }

    @Override
    public void method_5773() {
        super.method_5773();
        if (!method_37908().field_9236 && !waypoints.isEmpty() && method_5942().method_6357()) {
            ticksStuck++;
            if (ticksStuck > 60) {
                ticksStuck = 0;
                currentWaypoint = (currentWaypoint + 1) % waypoints.size();
                class_2338 target = waypoints.get(currentWaypoint);
                class_11 path = method_5942().method_6348(target, 1);
                if (path != null) method_5942().method_6334(path, 0.6);
            }
        } else {
            ticksStuck = 0;
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "controller", 5, this::predicate));
    }

    private <T extends GeoAnimatable> PlayState predicate(AnimationState<T> state) {
        if (state.isMoving()) {
            state.getController().setAnimation(RawAnimation.begin().then("animation.model.walk", Animation.LoopType.LOOP));
        } else {
            state.getController().setAnimation(RawAnimation.begin().then("animation.model.idle", Animation.LoopType.LOOP));
        }
        return PlayState.CONTINUE;
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return cache;
    }

    @Override
    public class_1269 method_5992(class_1657 player, class_1268 hand) {
        if (!this.method_37908().field_9236 && player instanceof class_3222) {
            player.method_17355(this);
        }
        return class_1269.field_5812;
    }

    @Override
    public class_2561 method_5476() {
        if (npcInfo != null) return class_2561.method_43470(npcInfo.name);
        return class_2561.method_43470("§7NPC");
    }

    @Nullable
    @Override
    public class_1703 createMenu(int syncId, class_1661 inv, class_1657 player) {
        if (npcInfo == null) return null;
        return switch (npcInfo.type) {
            case MERCHANT -> new MerchantScreenHandler(syncId, inv,
                    class_3914.method_17392(this.method_37908(), this.method_24515()), this);
            case TRANSPORTER -> new TransporterScreenHandler(syncId, inv,
                    class_3914.method_17392(this.method_37908(), this.method_24515()), this);
            default -> new DialogueScreenHandler(syncId, inv,
                    class_3914.method_17392(this.method_37908(), this.method_24515()), this);
        };
    }

    @Override
    public void method_5652(class_2487 nbt) {
        super.method_5652(nbt);
        nbt.method_10569("NpcIndex", npcIndex);
    }

    @Override
    public void method_5749(class_2487 nbt) {
        super.method_5749(nbt);
        if (nbt.method_10545("NpcIndex")) setNpcInfo(nbt.method_10550("NpcIndex"));
    }

    public NpcData.Info getNpcInfo() { return npcInfo; }
}
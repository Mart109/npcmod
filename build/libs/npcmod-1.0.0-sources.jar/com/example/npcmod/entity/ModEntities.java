package com.example.npcmod.entity;

import com.example.npcmod.NpcMod;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_7923;

public class ModEntities {
    public static final class_1299<CustomNpcEntity> CUSTOM_NPC = class_2378.method_10230(
            class_7923.field_41177,
            new class_2960(NpcMod.MOD_ID, "custom_npc"),
            FabricEntityTypeBuilder.create(class_1311.field_6294, CustomNpcEntity::new)
                    .dimensions(class_4048.method_18385(0.6f, 1.8f))
                    .trackRangeBlocks(64)
                    .build()
    );

    public static void register() {}
}
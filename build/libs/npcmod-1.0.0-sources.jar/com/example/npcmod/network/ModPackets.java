package com.example.npcmod.network;

import com.example.npcmod.NpcMod;
import com.example.npcmod.reputation.ReputationManager;
import com.example.npcmod.screen.TransporterScreenHandler;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1703;
import net.minecraft.class_2561;
import net.minecraft.class_2960;

public class ModPackets {
    public static final class_2960 DIALOGUE_CHOICE = NpcMod.id("dialogue_choice");
    public static final class_2960 TELEPORT_REQUEST = NpcMod.id("teleport_request");

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(DIALOGUE_CHOICE, (server, player, handler, buf, responseSender) -> {
            int delta = buf.readInt();
            server.execute(() -> {
                ReputationManager.changeReputation(server, player.method_5667(), delta);
                player.method_7353(class_2561.method_43470("§aРепутация изменена на " + delta), true);
            });
        });

        ServerPlayNetworking.registerGlobalReceiver(TELEPORT_REQUEST, (server, player, handler1, buf, responseSender) -> {
            server.execute(() -> {
                class_1703 screenHandler = player.field_7512;
                if (screenHandler instanceof TransporterScreenHandler transporter) {
                    transporter.teleport(player);
                }
            });
        });
    }

    public static void registerClient() {}
}
package com.example.npcmod.command;

import com.example.npcmod.entity.CustomNpcEntity;
import com.example.npcmod.entity.ModEntities;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;

public class NpcCommand {
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("npc")
                .requires(source -> source.method_9259(2))
                .then(class_2170.method_9247("create")
                        .then(class_2170.method_9244("index", IntegerArgumentType.integer(0, 32))
                                .executes(ctx -> {
                                    int index = IntegerArgumentType.getInteger(ctx, "index");
                                    class_3218 world = ctx.getSource().method_9225();
                                    class_2338 pos = class_2338.method_49638(ctx.getSource().method_9222());

                                    CustomNpcEntity npc = new CustomNpcEntity(ModEntities.CUSTOM_NPC, world);
                                    npc.method_5808(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5, 0, 0);
                                    npc.setNpcInfo(index);
                                    world.method_8649(npc);

                                    ctx.getSource().method_9226(() ->
                                                    class_2561.method_43470("§a✅ Создан NPC: " +
                                                            com.example.npcmod.npcdata.NpcData.NPC_NAMES[index]),
                                            true);
                                    return 1;
                                })
                        )
                )
        );
    }
}
package com.example.npcmod.item;

import com.example.npcmod.NpcMod;
import com.example.npcmod.entity.ModEntities;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1792;
import net.minecraft.class_1826;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7706;
import net.minecraft.class_7923;

public class ModItems {
    public static final class_1792 NPC_SPAWN_EGG = registerItem("npc_spawn_egg",
            new class_1826(ModEntities.CUSTOM_NPC, 0x4B0082, 0xFFD700,
                    new FabricItemSettings()));

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(NpcMod.MOD_ID, name), item);
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(class_7706.field_40205).register(entries ->
                entries.method_45421(NPC_SPAWN_EGG));
    }
}
package com.example.npcmod.screen;

import com.example.npcmod.NpcMod;
import com.example.npcmod.money.MoneyManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_746;

public class TransporterScreen extends class_465<TransporterScreenHandler> {
    private static final class_2960 TEXTURE = new class_2960(NpcMod.MOD_ID, "textures/gui/transporter_bg.png");

    public TransporterScreen(TransporterScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.field_2792 = 176;
        this.field_2779 = 166;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        method_37063(class_4185.method_46430(class_2561.method_43470("§b✨ Телепортироваться"), btn -> {
            ClientPlayNetworking.send(NpcMod.id("teleport_request"), PacketByteBufs.empty());
            method_25419();
        }).method_46434(x + 25, y + 50, 126, 20).method_46431());
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        RenderSystem.setShaderColor(1,1,1,1);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_25302(TEXTURE, x, y, 0, 0, field_2792, field_2779);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context);
        super.method_25394(context, mouseX, mouseY, delta);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        var player = class_310.method_1551().field_1724;
        if (player != null) {
            int money = MoneyManager.getMoney(player.method_5667());
            context.method_51439(field_22793, class_2561.method_43470("§6💰 " + money), x + 8, y + 6, 0xFFFFFF, false);
        }
        context.method_51439(field_22793, class_2561.method_43470("§eЦена: 50-500 монет"), x + 25, y + 30, 0xFFAA00, false);
    }
}
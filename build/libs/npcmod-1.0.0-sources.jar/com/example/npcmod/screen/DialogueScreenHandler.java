package com.example.npcmod.screen;

import com.example.npcmod.entity.CustomNpcEntity;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_3914;

public class DialogueScreenHandler extends class_1703 {
    protected final class_3914 context;
    protected final CustomNpcEntity npc;

    public DialogueScreenHandler(int syncId, class_1661 playerInventory) {
        this(syncId, playerInventory, class_3914.field_17304, null);
    }

    public DialogueScreenHandler(int syncId, class_1661 playerInventory, class_3914 context, CustomNpcEntity npc) {
        super(ModScreenHandlers.DIALOGUE_SCREEN_HANDLER, syncId);
        this.context = context;
        this.npc = npc;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }
}
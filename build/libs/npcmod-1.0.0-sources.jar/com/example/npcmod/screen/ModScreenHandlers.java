package com.example.npcmod.screen;

import com.example.npcmod.NpcMod;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7701;
import net.minecraft.class_7923;

public class ModScreenHandlers {
    public static final class_3917<DialogueScreenHandler> DIALOGUE_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187,
                    new class_2960(NpcMod.MOD_ID, "dialogue"),
                    new class_3917<>(DialogueScreenHandler::new, class_7701.field_40182));

    public static final class_3917<MerchantScreenHandler> MERCHANT_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187,
                    new class_2960(NpcMod.MOD_ID, "merchant"),
                    new class_3917<>((syncId, inv) -> new MerchantScreenHandler(syncId, inv), class_7701.field_40182));

    public static final class_3917<TransporterScreenHandler> TRANSPORTER_SCREEN_HANDLER =
            class_2378.method_10230(class_7923.field_41187,
                    new class_2960(NpcMod.MOD_ID, "transporter"),
                    new class_3917<>((syncId, inv) -> new TransporterScreenHandler(syncId, inv), class_7701.field_40182));
}
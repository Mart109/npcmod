package com.example.npcmod.screen;

import com.example.npcmod.NpcMod;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.class_1661;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_465;

public class DialogueScreen extends class_465<DialogueScreenHandler> {
    private static final class_2960 TEXTURE = new class_2960(NpcMod.MOD_ID, "textures/gui/dialogue_bg.png");

    public DialogueScreen(DialogueScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.field_2792 = 350;
        this.field_2779 = 220;
        this.field_25270 = 1000;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        method_37063(class_4185.method_46430(
                        class_2561.method_43470("§a✨ Помочь (+10)"),
                        btn -> sendChoice(10))
                .method_46434(x + 50, y + 140, 120, 20).method_46431());

        method_37063(class_4185.method_46430(
                        class_2561.method_43470("§c💔 Отказать (-5)"),
                        btn -> sendChoice(-5))
                .method_46434(x + 180, y + 140, 120, 20).method_46431());

        method_37063(class_4185.method_46430(
                        class_2561.method_43470("§7🚪 Уйти"),
                        btn -> method_25419())
                .method_46434(x + 270, y + 10, 60, 20).method_46431());
    }

    private void sendChoice(int delta) {
        class_2540 buf = PacketByteBufs.create();
        buf.writeInt(delta);
        ClientPlayNetworking.send(NpcMod.id("dialogue_choice"), buf);
        method_25419();
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        RenderSystem.setShaderColor(1f, 1f, 1f, 1f);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;
        context.method_25302(TEXTURE, x, y, 0, 0, field_2792, field_2779);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context);
        super.method_25394(context, mouseX, mouseY, delta);
        int x = (field_22789 - field_2792) / 2;
        int y = (field_22790 - field_2779) / 2;

        context.method_51439(field_22793, class_2561.method_43470("§6§lПривет, путник!"), x + 20, y + 20, 0xFFFFFF, false);
        context.method_51439(field_22793, class_2561.method_43470("§7Твои поступки определяют твою судьбу."), x + 20, y + 45, 0xCCCCCC, false);
        context.method_51439(field_22793, class_2561.method_43470("§eВыбери мудро:"), x + 20, y + 75, 0xFFAA00, false);
    }
}
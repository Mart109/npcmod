package com.example.npcmod.screen;

import com.example.npcmod.entity.CustomNpcEntity;
import com.example.npcmod.money.MoneyManager;
import com.example.npcmod.npcdata.NpcData.Info;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3914;

public class TransporterScreenHandler extends class_1703 {
    private final class_3914 context;
    private final CustomNpcEntity npc;

    public TransporterScreenHandler(int syncId, class_1661 playerInventory) {
        this(syncId, playerInventory, class_3914.field_17304, null);
    }

    public TransporterScreenHandler(int syncId, class_1661 playerInventory, class_3914 context, CustomNpcEntity npc) {
        super(ModScreenHandlers.TRANSPORTER_SCREEN_HANDLER, syncId);
        this.context = context;
        this.npc = npc;
    }

    public boolean teleport(class_3222 player) {
        var info = npc.getNpcInfo();
        if (info == null) return false;

        int price = info.teleportPrice;
        if (!MoneyManager.spendMoney(player.method_5667(), price)) {
            player.method_7353(class_2561.method_43470("§cНедостаточно монет! Нужно " + price), true);
            return false;
        }

        class_2338 dest = switch (info.destinationName) {
            case "§6🏛️ Золотой Город" -> new class_2338(1000, 64, 1000);
            case "§a🌳 Изумрудный Лес" -> new class_2338(-500, 70, 800);
            default -> new class_2338(0, 64, 0);
        };

        player.method_14251((class_3218) player.method_37908(), dest.method_10263()+0.5, dest.method_10264(), dest.method_10260()+0.5, player.method_36454(), player.method_36455());
        player.method_7353(class_2561.method_43470("§a✨ Телепортация в " + info.destinationName + "!"), true);
        return true;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }
}
package com.example.npcmod.screen;

import com.example.npcmod.entity.CustomNpcEntity;
import com.example.npcmod.money.MoneyManager;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3914;

public class MerchantScreenHandler extends class_1703 {
    private final class_3914 context;
    private final CustomNpcEntity npc;
    private final class_1263 inventory;

    private static final class_1799[] OFFERS = {
            new class_1799(class_1802.field_8620, 1),
            new class_1799(class_1802.field_8477, 1),
            new class_1799(class_1802.field_8687, 1),
            new class_1799(class_1802.field_8463, 1)
    };
    private static final int[] PRICES = {5, 20, 15, 30};

    public MerchantScreenHandler(int syncId, class_1661 playerInventory) {
        this(syncId, playerInventory, class_3914.field_17304, null);
    }

    public MerchantScreenHandler(int syncId, class_1661 playerInventory, class_3914 context, CustomNpcEntity npc) {
        super(ModScreenHandlers.MERCHANT_SCREEN_HANDLER, syncId);
        this.context = context;
        this.npc = npc;
        this.inventory = new class_1277(4);

        for (int i = 0; i < 4; i++) {
            this.method_7621(new class_1735(inventory, i, 30 + i * 30, 35) {
                @Override
                public boolean method_7680(class_1799 stack) { return false; }
            });
            inventory.method_5447(i, OFFERS[i].method_7972());
        }

        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 9; ++j) {
                this.method_7621(new class_1735(playerInventory, j + i * 9 + 9, 8 + j * 18, 84 + i * 18));
            }
        }
        for (int i = 0; i < 9; ++i) {
            this.method_7621(new class_1735(playerInventory, i, 8 + i * 18, 142));
        }
    }

    @Override
    public boolean method_7604(class_1657 player, int id) {
        if (id >= 0 && id < OFFERS.length && player instanceof class_3222 serverPlayer) {
            int price = PRICES[id];
            if (MoneyManager.spendMoney(serverPlayer.method_5667(), price)) {
                class_1799 bought = OFFERS[id].method_7972();
                if (!serverPlayer.method_31548().method_7394(bought)) {
                    serverPlayer.method_7328(bought, false);
                }
                serverPlayer.method_7353(class_2561.method_43470("§aКуплено за " + price + " монет!"), true);
            } else {
                serverPlayer.method_7353(class_2561.method_43470("§cНедостаточно монет! Нужно " + price), true);
            }
        }
        return true;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }
}
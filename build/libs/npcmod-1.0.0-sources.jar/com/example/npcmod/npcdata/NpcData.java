package com.example.npcmod.npcdata;

import com.example.npcmod.NpcMod;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_2960;

public class NpcData {
    public enum NpcType {
        MERCHANT("§6🏪 Торговец"),
        TRANSPORTER("§b🚀 Проводник"),
        DIALOGUE("§a💬 Мудрец");

        public final String displayName;
        NpcType(String displayName) { this.displayName = displayName; }
    }

    public static class Info {
        public final String name;
        public final NpcType type;
        public final class_2960 texture;
        public String destinationName;
        public int teleportPrice;

        public Info(String name, NpcType type, String texturePath) {
            this.name = name;
            this.type = type;
            this.texture = new class_2960(NpcMod.MOD_ID, "textures/entity/" + texturePath + ".png");
        }
    }

    private static final Map<UUID, Info> NPC_INFO = new HashMap<>();

    public static final String[] NPC_NAMES = {
            "§6Боб", "§6Элис", "§6Чарли", "§6Диана", "§6Эван",
            "§6Фиона", "§6Гарри", "§6Холли", "§6Ирвин", "§6Джулия",
            "§bЛарри", "§bМолли", "§bНейт", "§bОливия", "§bПитер",
            "§bКуинн", "§bРэйчел", "§bСэм", "§bТина", "§bУилл",
            "§aВинсент", "§aВенди", "§aКсавьер", "§aИветта", "§aЗак",
            "§eАдам", "§eБетти", "§eКарл", "§eДейзи", "§eЭдгар",
            "§7Фрэнк", "§7Грейс", "§7Генри"
    };

    public static final NpcType[] NPC_TYPES = new NpcType[33];
    static {
        for (int i = 0; i < 10; i++) NPC_TYPES[i] = NpcType.MERCHANT;
        for (int i = 10; i < 20; i++) NPC_TYPES[i] = NpcType.TRANSPORTER;
        for (int i = 20; i < 33; i++) NPC_TYPES[i] = NpcType.DIALOGUE;
    }

    public static final String[] TEXTURE_PATHS = {
            "merchant1", "merchant2", "merchant3", "merchant4", "merchant5",
            "merchant6", "merchant7", "merchant8", "merchant9", "merchant10",
            "transporter1", "transporter2", "transporter3", "transporter4", "transporter5",
            "transporter6", "transporter7", "transporter8", "transporter9", "transporter10",
            "sage1", "sage2", "sage3", "sage4", "sage5",
            "guard1", "guard2", "guard3", "guard4", "guard5",
            "villager1", "villager2", "villager3"
    };

    public static final String[] DESTINATIONS = {
            null, null, null, null, null, null, null, null, null, null,
            "§6🏛️ Золотой Город", "§a🌳 Изумрудный Лес", "§b💎 Алмазные Пещеры",
            "§d☁️ Небесный Храм", "§1🌊 Подводное Царство", "§c🌋 Вулкан Дракона",
            "§3❄️ Ледяная Крепость", "§5📚 Забытая Библиотека", "§2🌸 Цветущие Сады",
            "§8🏺 Руины Древних",
            null, null, null, null, null, null, null, null, null, null, null, null, null
    };

    public static final int[] TELEPORT_PRICES = new int[33];
    static {
        for (int i = 10; i < 20; i++) TELEPORT_PRICES[i] = 50 + (i - 10) * 25;
    }

    public static Info getInfo(UUID uuid) {
        return NPC_INFO.get(uuid);
    }

    public static void registerNpc(UUID uuid, int index) {
        if (index >= 0 && index < 33) {
            Info info = new Info(NPC_NAMES[index], NPC_TYPES[index], TEXTURE_PATHS[index]);
            if (NPC_TYPES[index] == NpcType.TRANSPORTER) {
                info.destinationName = DESTINATIONS[index];
                info.teleportPrice = TELEPORT_PRICES[index];
            }
            NPC_INFO.put(uuid, info);
        }
    }
}